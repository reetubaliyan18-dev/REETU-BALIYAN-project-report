#!/bin/bash
echo "LabOps installation: modified version"
